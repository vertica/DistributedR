#include "contour_test.h"

int main(int /*argc*/, char* /*argv*/[])
{
    contour::contour_test();
    return 0;
}
