// main.cpp : Defines the entry point for the console application.
//

#include "commandline.h"
#include "designs.c"
#include <stdio.h>
#include <sys/stat.h>
#include <string>
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>
#include <glob.h>

extern int yydebug;

bool progress(double percent, void *)
{
    if (percent>=0 && percent<=100)
        fprintf(stderr, "%3d%%\r", (int)percent);
    else
        fprintf(stderr, "    \r");
    return true;
}

//Search for a pattern, read the files and put content into ret
void Search_Read(const char *fname, std::list<std::pair<std::string, std::string>> &ret)
{
    glob_t g;
    int r = glob(fname, GLOB_NOSORT, NULL, &g);
    if (r) return;
    for (unsigned u = 0; u<g.gl_pathc; u++) {
        FILE *in = fopen(g.gl_pathv[u], "r");
        if (in) {
            char *buffer = ReadFile(in);
            if (buffer) {
                const std::string name = g.gl_pathv[u];
                const size_t pos = name.find_last_of('/');
                ret.emplace_back(g.gl_pathv[u] + pos + 1, buffer);
                free(buffer);
            }
            fclose(in);
        }
    }
    globfree(&g);
}


#define RCDIR_NAME ".msc-genrc"
#define LOAD_FILE_NAME ".msc-generator-load"

int main(int argc, char* argv[])
{
    //Get msc-genrc dir
    const char *ch = getenv("MSC_GEN_RC");
    std::string hdir = ch ? ch : "";
    if (hdir.length()==0) {
        ch = getenv("HOME");
        hdir = ch ? ch : "";
        if (hdir.length()==0) {
            struct passwd *pw = getpwuid(getuid());
            hdir = pw->pw_dir;
        }
    }
    hdir.append("/");

    //Load progress balance data
    std::string fname = hdir + LOAD_FILE_NAME;
    FILE *fin = fopen(fname.c_str(), "r");
    std::string load_data;
    if (fin) {
        struct stat st;
        if (stat(fname.c_str(), &st) == 0) {
            const off_t len = st.st_size;
            char *buff = (char*)malloc(len+1);
            size_t r = fread(buff, 1, len, fin);
            buff[len] = 0;
            if (r == size_t(len))
                load_data = buff;
            free(buff);
            fclose(fin);
        }
    }

    //Copy args
    bool oLoadDesigns = true;
    std::list<std::string> args;
    for(int i=1; i<argc; i++) {
        args.push_back(std::string(argv[i]));
        if (args.back() == "--no-designs")
            oLoadDesigns = false;
    }

    //Prepare shapes and designs
    std::list<std::pair<std::string, std::string>> design_files;
    if (oLoadDesigns) {
        design_files.emplace_back("[designlib]", designs);
        Search_Read((hdir+RCDIR_NAME "/*.signalling").c_str(), design_files);
    }

    //Do it
    int ret = do_main(args, design_files, "\\mn(10)", progress, NULL, &load_data);

    //Write out progress balance data
    FILE *fout = fopen(fname.c_str(), "w");
    if (fout) {
        fwrite(load_data.c_str(), load_data.length(), 1, fout);
        fclose(fout);
    }
    return ret;
}


