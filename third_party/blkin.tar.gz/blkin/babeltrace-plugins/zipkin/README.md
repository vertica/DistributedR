babeltrace-zipkin plugin
========================

In order to use this plugin, the traces created by LTTng should follow a 
specific format. This format is provided in zipkin_trace.h file. If this
format is not followed the traces will be dropped.
