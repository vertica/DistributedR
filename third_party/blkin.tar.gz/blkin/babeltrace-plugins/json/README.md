babeltrace-json plugin
========================

This plugin enables us to send LTTng trace data to a Scribe server in a valid
json format
