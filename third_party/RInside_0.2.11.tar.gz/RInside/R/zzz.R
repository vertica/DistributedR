#.First.lib <- function(lib, pkg) {
#    cat("Loaded RInside.\n")
#}
