### R code from vignette source 'Rcpp-attributes.Rnw'

###################################################
### code chunk number 1: Rcpp-attributes.Rnw:30-32
###################################################
prettyVersion <- packageDescription("Rcpp")$Version
prettyDate <- format(Sys.Date(), "%B %e, %Y")


