require(data.table)
options(warn=2)
test.data.table()
test.data.table(verbose=TRUE)
# calling it again can reveal some memory bugs, verbose to check the verbose messages run ok


